import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class DescompactarEReorganizar {

    public static void main(String[] args) {
        // Caminho da pasta contendo os arquivos .zip
        String pastaOrigem = "C:\\Users\\ftava\\Downloads\\Descompactar";
        // Caminho para a pasta de saída consolidada
        String pastaDestino = "C:\\Users\\ftava\\Downloads\\Descompactar\\Descompactado";

        try {
            descompactarArquivos(pastaOrigem, pastaDestino);
            System.out.println("Todos os arquivos foram descompactados e reorganizados na pasta: " + pastaDestino);
        } catch (IOException e) {
            System.err.println("Ocorreu um erro: " + e.getMessage());
        }
    }

    public static void descompactarArquivos(String pastaOrigem, String pastaDestino) throws IOException {
        File pasta = new File(pastaOrigem);
        File destino = new File(pastaDestino);

        // Cria a pasta de destino se ela não existir
        if (!destino.exists()) {
            destino.mkdirs();
        }

        // Itera por todos os arquivos na pasta de origem
        File[] arquivos = pasta.listFiles((dir, name) -> name.toLowerCase().endsWith(".zip"));
        if (arquivos == null || arquivos.length == 0) {
            System.out.println("Nenhum arquivo .zip encontrado na pasta de origem.");
            return;
        }

        for (File arquivoZip : arquivos) {
            System.out.println("Descompactando: " + arquivoZip.getName());
            descompactarArquivoZip(arquivoZip, destino);
        }
    }

    private static void descompactarArquivoZip(File arquivoZip, File destino) throws IOException {
        try (ZipFile zipFile = new ZipFile(arquivoZip)) {
            Enumeration<? extends ZipEntry> entries = zipFile.entries();

            while (entries.hasMoreElements()) {
                ZipEntry entrada = entries.nextElement();
                File arquivoDestino = new File(destino, entrada.getName());

                // Cria as pastas necessárias
                if (entrada.isDirectory()) {
                    arquivoDestino.mkdirs();
                } else {
                    // Garante que as pastas existam
                    arquivoDestino.getParentFile().mkdirs();

                    // Copia o conteúdo do arquivo
                    try (InputStream entradaStream = zipFile.getInputStream(entrada);
                         OutputStream saidaStream = new FileOutputStream(arquivoDestino)) {
                        byte[] buffer = new byte[1024];
                        int bytesLidos;
                        while ((bytesLidos = entradaStream.read(buffer)) != -1) {
                            saidaStream.write(buffer, 0, bytesLidos);
                        }
                    }
                }
            }
        }
    }
}
