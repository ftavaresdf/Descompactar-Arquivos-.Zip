import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class DescompactarEReorganizarGUI {

    public static void main(String[] args) {
        // Criação da interface gráfica
        SwingUtilities.invokeLater(DescompactarEReorganizarGUI::criarInterface);
    }

    private static void criarInterface() {
        JFrame frame = new JFrame("Descompactar Notas Exportadas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 200);

        // Layout
        frame.setLayout(new GridLayout(3, 2, 10, 10));

        // Labels
        JLabel lblOrigem = new JLabel("Pasta de Origem:");
        JLabel lblDestino = new JLabel("Pasta de Destino:");

        // Campos de texto
        JTextField txtOrigem = new JTextField();
        JTextField txtDestino = new JTextField();

        // Botões
        JButton btnSelecionarOrigem = new JButton("Selecionar...");
        JButton btnSelecionarDestino = new JButton("Selecionar...");
        JButton btnExecutar = new JButton("Executar");
        
        
     // Ajustando tamanhos
        txtOrigem.setPreferredSize(new Dimension(300, 25));
        txtDestino.setPreferredSize(new Dimension(300, 25));
        btnSelecionarOrigem.setPreferredSize(new Dimension(100, 25));
        btnSelecionarDestino.setPreferredSize(new Dimension(100, 25));
        btnExecutar.setPreferredSize(new Dimension(150, 30));


        // Ação para selecionar pasta de origem
        btnSelecionarOrigem.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int result = chooser.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                txtOrigem.setText(chooser.getSelectedFile().getAbsolutePath());
            }
        });

        // Ação para selecionar pasta de destino
        btnSelecionarDestino.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int result = chooser.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                txtDestino.setText(chooser.getSelectedFile().getAbsolutePath());
            }
        });

        // Ação para executar a descompactação
        btnExecutar.addActionListener(e -> {
            String pastaOrigem = txtOrigem.getText();
            String pastaDestino = txtDestino.getText();

            if (pastaOrigem.isEmpty() || pastaDestino.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Por favor, selecione as pastas de origem e destino.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                descompactarArquivos(pastaOrigem, pastaDestino);
                JOptionPane.showMessageDialog(frame, "Arquivos descompactados com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Erro ao descompactar os arquivos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Adicionar componentes ao frame
        frame.add(lblOrigem);
        frame.add(txtOrigem);
        frame.add(btnSelecionarOrigem);
        frame.add(lblDestino);
        frame.add(txtDestino);
        frame.add(btnSelecionarDestino);

        // Adicionar botão de execução
        frame.add(new JLabel()); // Espaço vazio
        frame.add(btnExecutar);

        // Exibir a interface
        frame.setVisible(true);
    }

    public static void descompactarArquivos(String pastaOrigem, String pastaDestino) throws IOException {
        File pasta = new File(pastaOrigem);
        File destino = new File(pastaDestino);

        // Cria a pasta de destino se ela não existir
        if (!destino.exists()) {
            destino.mkdirs();
        }

        // Itera por todos os arquivos na pasta de origem
        File[] arquivos = pasta.listFiles((dir, name) -> name.toLowerCase().endsWith(".zip"));
        if (arquivos == null || arquivos.length == 0) {
            System.out.println("Nenhum arquivo .zip encontrado na pasta de origem.");
            return;
        }

        for (File arquivoZip : arquivos) {
            System.out.println("Descompactando: " + arquivoZip.getName());
            descompactarArquivoZip(arquivoZip, destino);
        }
    }

    private static void descompactarArquivoZip(File arquivoZip, File destino) throws IOException {
        try (ZipFile zipFile = new ZipFile(arquivoZip)) {
            Enumeration<? extends ZipEntry> entries = zipFile.entries();

            while (entries.hasMoreElements()) {
                ZipEntry entrada = entries.nextElement();
                File arquivoDestino = new File(destino, entrada.getName());

                // Cria as pastas necessárias
                if (entrada.isDirectory()) {
                    arquivoDestino.mkdirs();
                } else {
                    // Garante que as pastas existam
                    arquivoDestino.getParentFile().mkdirs();

                    // Copia o conteúdo do arquivo
                    try (InputStream entradaStream = zipFile.getInputStream(entrada);
                         OutputStream saidaStream = new FileOutputStream(arquivoDestino)) {
                        byte[] buffer = new byte[1024];
                        int bytesLidos;
                        while ((bytesLidos = entradaStream.read(buffer)) != -1) {
                            saidaStream.write(buffer, 0, bytesLidos);
                        }
                    }
                }
            }
        }
    }
}
